var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","55a0df47-e08a-49ec-b4e6-71619dd9a909","e1ee3915-6122-4fef-9c6b-d79877e0c8d7"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":8,"looping":true,"frameDelay":3,"version":"B.CasujC7Q428wztgG4NJUBIUJijLr1S","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png","frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":4,"version":"Ua1y_dYilOgrDZqO7uTOalzrWzP_4kea","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"kiTEG1M4saULBLHkFSsSG5TJOaf0.yOS","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"55a0df47-e08a-49ec-b4e6-71619dd9a909":{"name":"meadow","sourceUrl":"assets/api/v1/animation-library/gamelab/PBJke0OcZeBcSCZ4Jf1odHo4h3du1gOK/category_backgrounds/meadow.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"PBJke0OcZeBcSCZ4Jf1odHo4h3du1gOK","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PBJke0OcZeBcSCZ4Jf1odHo4h3du1gOK/category_backgrounds/meadow.png"},"e1ee3915-6122-4fef-9c6b-d79877e0c8d7":{"name":"monkey_1","sourceUrl":"assets/api/v1/animation-library/gamelab/UYKpESoivry5AsqtbwQdIeCk9v9asMvE/category_animals/monkey.png","frameSize":{"x":308,"y":257},"frameCount":1,"looping":true,"frameDelay":2,"version":"UYKpESoivry5AsqtbwQdIeCk9v9asMvE","loadedFromSource":true,"saved":true,"sourceSize":{"x":308,"y":257},"rootRelativePath":"assets/api/v1/animation-library/gamelab/UYKpESoivry5AsqtbwQdIeCk9v9asMvE/category_animals/monkey.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var play=1;
var end=0;
var gameState= play;

var bbackground = createSprite(200,200,400,400);
var monkey = createSprite(100,360,10,10);
var ground = createSprite(200,390,400,10);
var count;
var bananaGroup = createGroup();
var rockGroup = createGroup();



function draw() {

background("white");

bbackground.setAnimation("meadow");
monkey.setAnimation("monkey");
monkey.scale=0.13;
monkey.collide(ground);


 if(gameState === play){
  count=World.frameCount/10;
  monkey.velocityY = monkey.velocityY+0.8;
  spawnBananas();
  spawnRock();
 if(keyDown("space") && monkey.y>=300){
 monkey.velocityY=-12; }
 
 if(monkey.isTouching(bananaGroup)){
  count=World.frameCount+10; 
 } 
 
 if(monkey.isTouching(rockGroup)){
   gameState=end;
  
 }
 }
 if(gameState === end) {
    bananaGroup.setVelocityXEach(0);
    bananaGroup.setLifetimeEach(-1);
    rockGroup.setVelocityXEach(0);
    rockGroup.setLifetimeEach(-1);
    monkey.setAnimation("monkey_1");
    
 
 
 }
 ground.visible=false;
 ground.x = ground.width /2;
   ground.velocityX=-5;

  drawSprites();
  
  text("Score:"+count,300,75);


}

function spawnBananas() {
  if(World.frameCount % 80 === 0) {
    var banana = createSprite(400,randomNumber(180,200),10,40);
    banana.velocityX = -6;
    banana.setAnimation("Banana");
   
    
    //assign scale and lifetime to the obstacle           
    banana.scale = 0.05;
    banana.lifetime = 70;
    //add each obstacle to the group
  bananaGroup.add(banana);
  }
}

function spawnRock() {
  if(World.frameCount % 300 === 0) {
    var rock = createSprite(400,385,2,10,40);
    rock.velocityX = -6;
    rock.setAnimation("Stone");
    
    //assign scale and lifetime to the obstacle           
    rock.scale = 0.3;
    rock.lifetime = 140;
    //add each obstacle to the group
  rockGroup.add(rock);
  }
}
  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
